﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Player : MonoBehaviour
{
    public float speed;
    public float maxY, minY;

    void Update()
    {

        float verticalInput = Input.GetAxis("Vertical");
        transform.position = transform.position + new Vector3(0 , verticalInput * speed * Time.deltaTime, 0);
        clamp();
     
    }
    private void clamp()
    {
        if (transform.position.y <= minY)
        {
            transform.position = new Vector3(transform.position.x, minY);
        }
        else if (transform.position.y >=maxY)
        {
            transform.position = new Vector3(transform.position.x, maxY);
        }
    }

}
