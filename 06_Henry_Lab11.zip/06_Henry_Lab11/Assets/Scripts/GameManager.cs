﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    public Text scoretxt;
    private int score;
    void Start()
    {
        score = 0;
        PlayerPrefs.SetInt("Score", 0);
    }

    void Update()
    {
        score = PlayerPrefs.GetInt("Score");
        scoretxt.text = "Score : " + score;
        print(PlayerPrefs.GetInt("Score"));
    }
}
